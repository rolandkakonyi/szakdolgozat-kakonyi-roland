<?php
/*
|-----------------
| Chip Error Manipulation
|------------------
*/

error_reporting(-1);

/*
|-----------------
| Chip Constant Manipulation
|------------------
*/

define( "CHIP_DEMO_FSROOT",				__DIR__ . "/" );

/*
|-----------------
| POST
|------------------
*/

if( $_POST ) {
	
	/*
	|-----------------
	| Chip Upload Class
	|------------------
	*/
	
	require_once("class.chip_upload.php");
	
	/*
	|-----------------
	| Upload(s) Directory
	|------------------
	*/
	
	$upload_directory = CHIP_DEMO_FSROOT . "uploads/";
	
	/*
	|-----------------
	| Class Instance
	|------------------
	*/
	
	$object = new chip_upload();
	
	/*
	|-----------------
	| $_FILES Manipulation
	|------------------
	*/
	
	$files = $object->get_upload_var( $_FILES['upload_file'] );
	//$object->chip_print( $files );
	
	/*
	|-----------------
	| Upload Output Array
	|------------------
	*/
	
	$upload_output = array();
	
	/*
	|-----------------
	| Upload File
	|------------------
	*/
	
	foreach( $files as $file ) {
	
		/*
		|---------------------------
		| Upload Inputs
		|---------------------------
		*/
		
		$args = array(
			  'upload_file'			=>	$file,
			  'upload_directory'	=>	$upload_directory,
			  'allowed_size'		=>	512000,
			  'extension_check'		=>	TRUE,
			  'upload_overwrite'	=>	FALSE,
		  );
		  
		$allowed_extensions = array (
						
			  /* Archives */
			  'zip'		=> FALSE,
			  '7z'		=> FALSE,
		  
			  /* Documents */
			  'csv'		=> TRUE,
			  'txt'		=> FALSE,
			  'pdf'		=> FALSE,
			  'doc' 	=> FALSE,
			  'xls'		=> FALSE,
			  'ppt'		=> FALSE,
			
			  /* Executables */
			  'exe'		=> FALSE,
		  
			  /* Images */
			  'gif'		=> FALSE,
			  'png'		=> FALSE,
			  'jpg'		=> FALSE,
			  'jpeg'	=> FALSE,
		  
			  /* Audio */
			  'mp3'		=> FALSE,
			  'wav'		=> FALSE,
		  
			  /* Video */
			  'mpeg'	=> FALSE,
			  'mpg'		=> FALSE,
			  'mpe'		=> FALSE,
			  'mov'		=> FALSE,
			  'avi'		=> FALSE
		  
		  );
		
		/*
		|---------------------------
		| Upload Hook
		|---------------------------
		*/		
		
		$upload_hook = $object->get_upload( $args, $allowed_extensions );		
		#$object->chip_print( $upload_hook );
		#exit;
		
		/*
		|---------------------------
		| Move File
		|---------------------------
		*/
		
		if( $upload_hook['upload_move'] == TRUE ) {
			
			/*
			|---------------------------
			| Any Logic by User
			|---------------------------
			*/
			
			/*
			|---------------------------
			| Move File
			|---------------------------
			*/
			
			$upload_output[] = $object->get_upload_move();
			//$object->chip_print( $upload_output );
		
		} else {
		
			/*$temp['uploaded_status'] = FALSE;
			$temp['uploaded_file'] = $upload_hook['upload_file']['name'] ;
			
			$upload_output[] = $temp;*/
		
		}
		
	
	} // foreach( $files as $file )
	
	/*
	|-----------------
	| Chip CSV Class
	|------------------
	*/
	
	require_once("class.chip_csv.php");
	$object_csv = new Chip_csv();
	
	/*
	|---------------------------
	| Read CSV File
	|---------------------------
	*/
	
	if( count( $upload_output ) >= 1 ) {
	
		foreach ( $upload_output as $val ) {
			
			if( $val['uploaded_status'] == 1 ) {
				
				/*
				|---------------------------
				| CSV Inputs
				|---------------------------
				*/
				
				$args = array (
						'csv_file'			=>	$val['uploaded_directory'],
						'csv_delimiter'		=>	$_POST['delimiter'],
						'csv_fields_num'	=>	FALSE,
						'csv_head_read'		=>	TRUE,
						'csv_head_label'	=>	FALSE,
					);
				
				$csv_output = $object_csv->get_read( $args );
				//$object_csv->chip_print( $csv_output );
			
			}
			
		} // foreach ( $upload_output as $val )
	
	} // if( count( $upload_output ) >= 1 )	

} // if( $_POST )

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" media="all" href="style.css" />
<title>Chip CSV Parser</title>
</head>

<body>

<div id="wrap">
  <div id="wrapdata">
    
    
    <div id="header">
      <div id="headerdata">      
        
        <div class="chipboxw1 chipstyle1">
          <div class="chipboxw1data">          
            <h2 class="margin0">Chip CSV Parser</h2>
          </div>
        </div>
        
            
      </div>
    </div>
    
    <div id="content">
      <div id="contentdata">
        
        <?php
        if( @$csv_output['csv_file_read'] == TRUE ):
		$csv_file_data = $csv_output['csv_file_data'];
		?>
        <div class="chipboxw1 chipstyle2">
          <div class="chipboxw1data">          
            <h2 class="margin0">File Read Successfully: Delimiter (<?php echo $_POST['delimiter']; ?>)</h2>
			  <hr />
              <p>Total Entries: <?php echo count( $csv_file_data ); ?> - Displaying no more than 5 at online CSV Parser Demo</p>
              <hr />
			  <?php
              
			  $i = 1;
			  
			  /* Loop Rows */
			  			  
			  foreach( $csv_file_data as $val ):
				
				  /* Loop Fields */
				  
				  foreach( $val as $val2 ) {
					echo $val2 . ", ";
				  }
					echo "<hr/>";
              
				  /* Display Limited to 5 */
				  if( $i++ == 5 ) {
					break;
				  }
			  
			  endforeach;
			  ?>
          </div>
        </div>
        <?php endif; ?>
        
        <div class="chipboxw1 chipstyle1">
          <div class="chipboxw1data">          
              <form method="post" action="" enctype="multipart/form-data">
                <p>Upload File 1: <input name="upload_file[]" id="upload_file[]" type="file" class="inputtext" /></p> 
                <p>Demo Allowed Files: .csv</p>
                <p>Delimiter:
                <select name="delimiter" id="delimiter">
                  <option value="," selected="selected">Comma (,)</option>
                  <option value=";">Semicollon (;)</option>
                </select>
                </p>
                <input type="submit" name="submit" value="Read CSV" />
              </form>
          </div>
        </div>
        
      </div>
    </div>
    
     <div id="footer">
      <div id="footerdata">
        
        <div class="chipboxw1 chipstyle1">
          <div class="chipboxw1data">          
            &copy; <a href="http://www.tutorialchip.com/">TutorialChip</a>
          </div>
        </div>
        
      </div>
    </div>
    
  </div>
</div>

</body>
</html>